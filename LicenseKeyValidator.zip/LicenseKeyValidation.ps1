﻿# Please visit https://help.syncfusion.com/common/essential-studio/licensing/licensing-faq/ci-license-validation for queries 

# Command to run LicenseKeyValidatorConsole.exe with specified parameters.
# Replace the parameters with the desired platform, version, and actual license key.
# Make sure all the parameters are placed within double quotes.

$result = & $PSScriptRoot"\LicenseKeyValidatorConsole.exe" /platform:"*" /version:"*" /licensekey:"*"

Write-Host $result